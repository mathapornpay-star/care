/* ==========================================================================
   CARELLE - Unified Application Script (script.js)
   รองรับการทำงานทุกหน้า: index.html, product.html, order.html, thankyou.html, admin.html
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  // 1. หน้า product.html (รายการสินค้า + ปุ่มกรอง mood)
  if (document.getElementById('product-list')) {
    initProductPage();
  }

  // 2. หน้า order.html (รับ item/price จาก URL, คำนวณตามจำนวน และบันทึกลง localStorage)
  if (document.getElementById('orderForm')) {
    initOrderPage();
  }

  // 3. หน้า admin.html (แสดงตารางคำสั่งซื้อจาก localStorage key 'bodyScentOrders')
  if (document.getElementById('ordersTable')) {
    initAdminPage();
  }
});

/* ==========================================================================
   1. PRODUCT PAGE (product.html)
   ========================================================================== */
async function initProductPage() {
  const productListEl = document.getElementById('product-list');
  const filterBarEl = document.getElementById('filter-bar');
  let allProducts = [];

  const scentToMoodMap = {
    'green tea fresh': 'fresh',
    'jasmine soft': 'sweet',
    'lavender dream': 'confident',
    'rose bloom': 'romance'
  };

  function getProductMood(product) {
    if (product.mood) return String(product.mood).toLowerCase().trim();
    if (product.scent) {
      const key = String(product.scent).toLowerCase().trim();
      return scentToMoodMap[key] || key;
    }
    return 'all';
  }

  function getScentClass(product) {
    const scent = String(product.scent || product.name || '').toLowerCase();
    if (scent.includes('rose')) return 'scent-rose';
    if (scent.includes('jasmine')) return 'scent-jasmine';
    if (scent.includes('lavender')) return 'scent-lavender';
    if (scent.includes('green tea') || scent.includes('greentea')) return 'scent-greentea';
    return '';
  }

  const urlParams = new URLSearchParams(window.location.search);
  const initialMoodParam = (urlParams.get('mood') || 'all').toLowerCase().trim();

  const filters = [
    { label: 'ทั้งหมด', value: 'all' },
    { label: 'Fresh', value: 'fresh' },
    { label: 'Sweet', value: 'sweet' },
    { label: 'Confident', value: 'confident' },
    { label: 'Romance', value: 'romance' }
  ];

  let currentMood = filters.some(f => f.value === initialMoodParam) ? initialMoodParam : 'all';

  function renderFilterButtons() {
    if (!filterBarEl) return;
    filterBarEl.innerHTML = '';

    filters.forEach(filter => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `filter-btn ${currentMood === filter.value ? 'active' : ''}`;
      btn.textContent = filter.label;
      btn.dataset.mood = filter.value;

      btn.addEventListener('click', () => {
        currentMood = filter.value;

        filterBarEl.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const newUrl = new URL(window.location.href);
        if (currentMood === 'all') {
          newUrl.searchParams.delete('mood');
        } else {
          newUrl.searchParams.set('mood', currentMood);
        }
        window.history.replaceState({}, '', newUrl);

        renderProducts();
      });

      filterBarEl.appendChild(btn);
    });
  }

  function renderProducts() {
    const filtered = currentMood === 'all'
      ? allProducts
      : allProducts.filter(item => getProductMood(item) === currentMood);

    if (filtered.length === 0) {
      productListEl.innerHTML = `
        <p class="text-center" style="grid-column: 1 / -1; color: var(--text-secondary); padding: 40px 0;">
          ไม่พบสินค้าในหมวดหมู่ที่เลือก
        </p>
      `;
      return;
    }

    productListEl.innerHTML = filtered.map(product => {
      const scentClass = getScentClass(product);
      const scentLabel = product.scent || product.mood || 'CARELLE';
      const itemText = `${product.name} (${product.size})`;
      const orderUrl = `order.html?item=${encodeURIComponent(itemText)}&price=${encodeURIComponent(product.price)}`;

      return `
        <article class="product-card ${scentClass}">
          <div class="product-image">
            <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy">
            <span class="product-size-badge">${escapeHtml(product.size)}</span>
          </div>
          <div class="product-info">
            <div class="product-scent-tag">
              <span class="scent-indicator"></span>
              <span>${escapeHtml(scentLabel)}</span>
            </div>
            <h3 class="product-title">${escapeHtml(product.name)}</h3>
            <p class="product-desc">${escapeHtml(product.description || '')}</p>
            <div class="product-footer">
              <span class="product-price">฿${Number(product.price).toLocaleString('th-TH')}</span>
              <a href="${orderUrl}" class="btn btn-primary btn-sm">สั่งซื้อ</a>
            </div>
          </div>
        </article>
      `;
    }).join('');
  }

  try {
    const response = await fetch('products.json');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    allProducts = await response.json();
    renderFilterButtons();
    renderProducts();
  } catch (error) {
    console.error('ไม่สามารถโหลดข้อมูล products.json ได้:', error);
    productListEl.innerHTML = `
      <p class="text-center" style="grid-column: 1 / -1; color: var(--text-secondary); padding: 40px 0;">
        เกิดข้อผิดพลาดในการโหลดรายการสินค้า กรุณาลองใหม่อีกครั้ง
      </p>
    `;
  }
}

/* ==========================================================================
   2. ORDER PAGE (order.html)
   ========================================================================== */
function initOrderPage() {
  const orderForm = document.getElementById('orderForm');
  const itemsInput = document.getElementById('items');
  const totalInput = document.getElementById('total');
  const quantityInput = document.getElementById('quantity');

  const urlParams = new URLSearchParams(window.location.search);
  const itemParam = urlParams.get('item') || '';
  const priceParam = urlParams.get('price') || '';
  const unitPrice = parseFloat(priceParam) || 0;

  if (itemsInput) {
    itemsInput.value = itemParam;
  }
  if (totalInput) {
    totalInput.value = priceParam;
  }

  // หากมีช่อง #quantity ให้คำนวณ #total อัตโนมัติตามจำนวน
  if (quantityInput && totalInput && unitPrice > 0) {
    quantityInput.addEventListener('input', () => {
      const qty = Math.max(1, parseInt(quantityInput.value, 10) || 1);
      totalInput.value = unitPrice * qty;
    });
  }

  orderForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const customerNameEl = document.getElementById('customerName');
    const contactEl = document.getElementById('contact');
    const noteEl = document.getElementById('note');

    const customerName = customerNameEl ? customerNameEl.value.trim() : '';
    const contact = contactEl ? contactEl.value.trim() : '';
    const itemsVal = itemsInput ? itemsInput.value.trim() : '';
    const totalVal = totalInput ? totalInput.value.trim() : '';
    const noteVal = noteEl ? noteEl.value.trim() : '';
    const qtyVal = quantityInput ? Math.max(1, parseInt(quantityInput.value, 10) || 1) : 1;

    if (!customerName || !contact || !itemsVal || !totalVal) {
      alert('กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน');
      return;
    }

    const payload = {
      customerName,
      contact,
      items: quantityInput ? `${itemsVal} x ${qtyVal}` : itemsVal,
      quantity: qtyVal,
      total: totalVal,
      note: noteVal,
      timestamp: new Date().toISOString()
    };

    try {
      const storageKey = 'bodyScentOrders';
      const existingRaw = localStorage.getItem(storageKey);
      let orders = [];

      if (existingRaw) {
        const parsed = JSON.parse(existingRaw);
        if (Array.isArray(parsed)) {
          orders = parsed;
        }
      }

      orders.push(payload);
      localStorage.setItem(storageKey, JSON.stringify(orders));

      window.location.href = 'thankyou.html';
    } catch (error) {
      console.error('เกิดข้อผิดพลาดในการบันทึกคำสั่งซื้อลง localStorage:', error);
      alert('ไม่สามารถบันทึกข้อมูลคำสั่งซื้อได้ กรุณาตรวจสอบการตั้งค่าเบราว์เซอร์ของคุณ');
    }
  });
}

/* ==========================================================================
   3. ADMIN PAGE (admin.html)
   ========================================================================== */
function initAdminPage() {
  const tableBody = document.querySelector('#ordersTable tbody');
  if (!tableBody) return;

  const headerCells = document.querySelectorAll('#ordersTable thead th');
  const colSpan = headerCells.length > 0 ? headerCells.length : 6;

  let orders = [];
  try {
    const raw = localStorage.getItem('bodyScentOrders');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        orders = parsed;
      }
    }
  } catch (error) {
    console.error('เกิดข้อผิดพลาดในการอ่านข้อมูลคำสั่งซื้อ:', error);
  }

  if (orders.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="${colSpan}" style="text-align: center; padding: 32px; color: var(--text-secondary);">
          ยังไม่มีคำสั่งซื้อ
        </td>
      </tr>
    `;
    return;
  }

  const sortedOrders = [...orders].sort((a, b) => {
    const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
    const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
    return timeB - timeA;
  });

  tableBody.innerHTML = sortedOrders.map(order => {
    const formattedDate = order.timestamp
      ? new Date(order.timestamp).toLocaleString('th-TH')
      : '-';

    const totalDisplay = order.total !== '' && !isNaN(Number(order.total))
      ? `฿${Number(order.total).toLocaleString('th-TH')}`
      : escapeHtml(String(order.total || '-'));

    return `
      <tr>
        <td>${escapeHtml(formattedDate)}</td>
        <td>${escapeHtml(order.customerName || '-')}</td>
        <td>${escapeHtml(order.contact || '-')}</td>
        <td>${escapeHtml(order.items || '-')}</td>
        <td>${totalDisplay}</td>
        <td>${escapeHtml(order.note || '-')}</td>
      </tr>
    `;
  }).join('');
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
